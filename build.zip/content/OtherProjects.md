## Project 1
Description
- Tags: Category 1
- Badges:
  - Badge [blue]
- Buttons:
  - Link [https://example.com]

## Project 2
Description
- Tags: Category 2
- Badges:
  - Badge [blue]
- Buttons:
  - Link [https://example.com]

## Project 3
Description
- Tags: Category 3
- Badges:
  - Badge [blue]
- Buttons:
  - Link [https://example.com]